--Change msg on title from 2.2 release to a reminder to join the dsc server.

# **Universal UB v2.2**

**Added Ultraviolet hosted via cloudflare workers!**
**Added 12 apps!**
**Added img2txt**
**Added ExtHang3r**
**Fixed method files being on the wrong repo (Couldn't update async)**
**Fixed fullscreen not working on quite a few pages 😎**
**Renamed the "gamefiles" repo to "files"**

<br>

# **Universal UB v2.19**

**Everything is now loaded async, allowing games, methods, unblockers and apps to load automatically on all URLs**

<br>

# **Universal UB v2.18**

**Just a shit ton of games (+41 from the previous "games" update)**

<br>

# **Universal UB v2.17**

**Added lots of games >:))) riddleschool, ducklife, papas, bloxorz, tboi, alot more.**
**Fixed formatting on the homepage, discord icon works properly now :)**
**Added new pages for settings and changelog (No longer on index.html anymore)**
**Added a button on the top right of index with a "site map" of sorts.**

<br>

# **Universal UB v2.16**

**Once again, not a shit ton of actual changes, but alot going on behind the scenes :)**
**Added slowroads.io and snow rider 3d**
**Experimental push, please report any bugs (NEW FORMATTING FOR ALL PAGES)**

<br>

# **Universal UB v2.15**

**Switched from using iframes to embeds for the about:blank urls, as iframes are scanned by securly but embeds are not 💀**
**Fixed emulatorJS (emulators page)**
**Added rigtools (UNBLOCK EVERYTHING :D)**
**Added Mit AI2 Companion exploit (Webview bypass)**

<br>

# **Universal UB v2.14**

**Added 2 goguard bypasses**
**Added pdfv2**
**Added caudns**
**Fixed the fixer from not fixing**

<br>

# **Universal UB v2.13**

**added new cloaking options**
**Added ltf 2 and 3**
**added 4 henry stickmin games**
**fixed wierd styling changes**

<br>

# **Universal UB v2.12**

**uhh I lied abt mit app inventor :3**
**Fixed a few files missing from "Mr. Mine"**
**Added PvZ, BTD4, Learn to fly 2, Learn to fly 3**
**Added the first app, win11 (Windows 11 in react by blueedge)**
**Added panic keys**
**Added page customization (Will be worked on in a later update)**

<br>

# **Universal UB v2.11**

**Added Geometry dash lite and "Mr. Mine"**
**Ability to scroll on game.html, ub.html and method.html pages**
**Testing out ads (Most likely won't be permanent)**

**Next update WILL have MIT app inventor and page customization :D**

<br>

# **Universal UB v2.1**

**Added some features that probably should've existed for a while now.**
**"fixer" which fixes games that don't let you embed (iframe) them**
**fixed mc1.8.8 and mc1.5.2 and removed precision mc because like 3 people used it one time**
**Added slope & cookie clicker.**
**Added a way to send responses and suggestions to me without joining the discord**
**And all the pages actually scroll now lol**
**Also added a discord plugin so you can talk without having an account**

**No MIT app inventor exploit YET, it'll be out soon. just keep an eye out.**

<br>

# **Universal UB v2.03**

**Styling changes in Games**
**Imported 5/6 methods into the methods page**
**Added @PDF to the unblockers page**
**Moved where the discord was (From settings to the bottom left of homepage)**
**Added utilities to the settings tab of homepage**
**About blank cloaker (any tab) ^**
**Open URL In current window (for kiosk exploits)**'
**Open URL In newtab**

**Cloaks are available in settings**

<br>

# **Universal UB v2.02**

**Added proper site cloaking with 4 options, docs, drive, classroom and clever**
**note: More will be added later**

**Cloaks are available in settings**

<br>

# **Universal UB v2.01!**
**200+ proxies**

**About blank version of the site**

<br>

# **Universal UB v2.0!**
**20+ More games**

**Entire site overhaul!**

**30+ new emulators**

**rizz**

**Play it here! [Click](https://uniub.github.io)**

<br>