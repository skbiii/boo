python3 -m http.server 25381 & sleep 2 && xdg-open http://localhost:25381
